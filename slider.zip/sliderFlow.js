$(document).ready(function(){
	$toBack = $('.toBack');
	$sliderFlow = $('.sliderFlow');

	/*aqui el ancho dle contenedor*/
	$widthView = ($('.contentSlider').width());
	function getSize(){
		return $('.sliderFlow li').size();
	}

	$pos = 0;


	$sliderFlow.find('li').css('width',$widthView + ('px'));
	

	$(document).on('click','.sliderFlow li a.action',function(){
		ms(this);
	});

	$toBack.on('click', function(){
		if ($pos == 1) {
				$toBack.css('display','none');
			};
		$sliderFlow.animate({left: parseInt($sliderFlow.css('left'))+($widthView )+ 'px'}, 240, function(){
			$sliderFlow.find('li:last-child').remove();
			$sliderFlow.css('width', ($widthView * getSize()) + 'px');
			$pos--;

			
		});

	})



	function ms(elem){
		$id = $(elem).attr('target-id')
		$sliderFlow.append( $($id).clone() );
		$(elem).closest('ul').animate({left: -($widthView * ($pos + 1)) + "px"}, 420, function(){
			$toBack.css('display','block');
		});
		$sliderFlow.css('width', ($widthView * getSize()) + 'px');
		$pos++;

	}
})